<html>
	<head>
		<title>Calc</title>
		<link rel="stylesheet" href="styles.css">
	</head>
	<body>
		<?php
		$y=$_POST['a'];
		$z=$_POST['b'];
		if (isset($_POST['btsuma'])) {
			$c=$y+$z;
			echo "$y+$z es: ".$c;
		}
		if (isset($_POST['btresta'])) {
			$c=$y-$z;
			echo "$y-$z es: ".$c;
		}
		if (isset($_POST['btmult'])) {
			$c=$y*$z;
			echo "$y*$z es: ".$c;
		}
		if (isset($_POST['btdiv'])) {
			
			if ($z != 0) {
				$c=$y/$z;
				echo "$y/$z es: ".$c;
			}
			else
			{
				$c=0;
				echo "Division no válida";
			}
		}
		if (isset($_POST['limpiar'])) {
			$y = "";
			$z = "";
		}

		?>
			<form action="calculadora.php" method="POST">
			Ingresa primer numero:<input type="text" name="a" value="<?php echo $y; ?>">
			<br>
			Ingresa otro numero:<input type="text" name="b" value="<?php echo $z; ?>">
			<br>
			<input type="submit" value= "suma" name="btsuma">
			<input type="submit" value= "resta" name="btresta">
			<input type="submit" value= "multiplicacion" name="btmult">
			<input type="submit" value= "division" name="btdiv">
			<input type="submit" value= "reset" name="limpiar">
			</form>
	</body>