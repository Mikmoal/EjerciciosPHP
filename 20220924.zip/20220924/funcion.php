<?php
function suma($uno,$dos){
	return $uno + $dos;
}
echo suma(suma(15,14));
?>